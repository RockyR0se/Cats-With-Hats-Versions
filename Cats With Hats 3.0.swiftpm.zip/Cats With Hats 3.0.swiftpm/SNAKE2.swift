import SwiftUI

struct Snake2: View {
    
    @State public var randomnumber: Int = 1
    @State public var spacesmoved: Int = 0
    @State public var spacesmovedrightfloat: Double = 0
    @State public var spacesmovedleftfloat: Double = 0
    @State public var spacesmovedupfloat: Double = 0
    @State public var spacesmoveddownfloat: Double = 0
    @State public var positionx: Int = 0
    @State public var positiony: Int = 0
    @State public var positionxleaf: Int = 0
    @State public var positionyleaf: Int = 0
    @State public var acorns: Int = 0
    @State public var leafpaddingx: Int = 0
    @State public var leafpaddingy: Int = 0
    @State public var leafpaddingxfloat: Double = 0
    @State public var leafpaddingyfloat: Double = 0
    @State public var disabledx: Int = 0
    @State public var disabledy: Int = 0
    @State public var positionyfloat: Double = 0
    @State public var acornsstring: String = "0"
    @State public var creature: String = "Creature"
    @State public var outfit: String = "Hat"
    @State public var congrats: String = "Can you help me grow my cat train and grow my sprout? I need to collect 4!"
    @State public var acorn2: Int = 0
    @State public var snakeleft: Double = 400
    @State public var snakeright: Double = 0
    @State public var snakeup: Double = 0
    @State public var snakedown: Double = 0
    @State public var snakeleft2: Double = 800
    @State public var snakeright2: Double = 0
    @State public var snakeup2: Double = 0
    @State public var snakedown2: Double = 0
    @State public var snakevalue1int: Int = 1
    @State public var snakevalue2int: Int = 0
    @State public var snakevalue3int: Int = 0
    @State public var snakevalue1: Double = 1
    @State public var snakevalue2: Double = 0
    @State public var snakevalue3: Double = 0
    @State public var snakevalue4: Double = 0
    @State public var snakevalue4int: Int = 0
    @State public var snakevalue5: Double = 0
    @State public var snakevalue5int: Int = 0
    @State public var snakeleft3: Double = 1200
    @State public var snakeright3: Double = 0
    @State public var snakeup3: Double = 0
    @State public var snakedown3: Double = 0
    @State public var snakeleft4: Double = 1600
    @State public var snakeright4: Double = 0
    @State public var snakeup4: Double = 0
    @State public var snakedown4: Double = 0
    @State public var snakevalue6: Double = 0
    @State public var snakevalue6int: Int = 0
    @State public var snakeleft5: Double = 2000
    @State public var snakeright5: Double = 0
    @State public var snakeup5: Double = 0
    @State public var snakedown5: Double = 0
    @State public var snake1pos: Int = 0
    @State public var snakesprout: String = "Snake"
    @State public var snakewink: String = "Snake"
    @State public var sproutopacity: Double = 1
    
    
    var body: some View {
        
        
        
        ZStack {
            Color(darkGreen)
                .ignoresSafeArea()
            Button("Collect") { 
                acorns = acorns + 1
                acorn2 = acorn2 + 1
                positionyfloat = Double(leafpaddingy)
                leafpaddingxfloat = 0
                leafpaddingyfloat = positionyfloat * 2
                //leafpaddingy = 0
                //positiony = leafpaddingy * 2 //fix this
                leafpaddingx = Int.random(in:-3...3)
                leafpaddingy = Int.random(in:0...1)
                leafpaddingxfloat += Double(leafpaddingx) * 235
                leafpaddingyfloat += Double(leafpaddingy) * -235
                //if leafpaddingy == 0 { //try put this in up down instead but mac said it didnt want to load :(
                //positiony = 0
                disabledy = leafpaddingy * 2
                disabledx = leafpaddingx * 2
                acornsstring = String(acorn2)
                if acorns == 5 {
                    creature = "CreatureHat"
                    outfit = "BowTie"
                    acornsstring = "0"
                    congrats = "Just the Bow Tie to go!"
                    acorn2 = 0
                }
                if acorns == 10 {
                    creature = "CreatureHatBowTie"
                    outfit = ""
                    congrats = "Thank you for your help! Would you like to play again?"
                }
                if snakevalue6int == 1 {
                    snakevalue6int = 0
                    snakevalue6 = 1
                }
                if snakevalue5int == 1 {
                    snakevalue5int = 0
                    snakevalue5 = 1
                    snakevalue6int = 1
                    
                }
                if snakevalue4int == 1 {
                    snakevalue4int = 0
                    snakevalue5 = 1
                    snakevalue5int = 1
                }
                if snakevalue3int == 1 {
                    snakevalue3int = 0
                    snakevalue4 = 1
                    snakevalue4int = 1
                }
                if snakevalue2int == 1 {
                    snakevalue3 = 1
                    snakevalue2int = 0
                    snakevalue3int = 1
                }
                if snakevalue1int == 1 {
                    snakevalue2 = 1
                    snakevalue2int = 1
                    snakevalue1int = 0
                }
                if snakevalue5int == 1 {
                    congrats = "Thank you for your help meow!"
                    snakesprout = "SproutWink"
                    snakewink = "Wink"
                    sproutopacity = 0
                    
                }
            
                
                
            }
            //disabledx = 100
            //disabledy = 100
            
            //make it so that it randomises every time the acorns is increased and that the collect button is disabled unless the cat has the same positionx and positiony as the acorn. make it so that the randomisation then converts to accurate padding positions aka. number of pips multiplied by 235, (470)
            
            //235 DID NOT WORK PLEASE FIX :((((
            .offset(y:250)
            .buttonStyle(.bordered)
            .tint(lightGreen)
            .disabled(disabledx != positionx || disabledy != positiony)
            
            
            
            Button("Right") { 
                
                withAnimation {
                    randomnumber = 1
                    spacesmovedrightfloat += Double(randomnumber) * 235
                    positionx = positionx + 1
                    //disabledx = leafpaddingx * 2
                    snakeright += Double(randomnumber) * 235
                    snakeright2 += Double(randomnumber) * 235
                    snakeright3 += Double(randomnumber) * 235
                    snakeright4 += Double(randomnumber) * 235
                    
                }
                
            }
            .buttonStyle(.bordered)
            .tint(lightGreen)
            .offset(y:400)
            .offset(x:100)
            .disabled(positionx == 6)
            Button("Left") { 
                
                withAnimation {
                    randomnumber = 1
                    spacesmovedleftfloat += Double(randomnumber) * 235
                    positionx = positionx - 1
                    snakeleft += Double(randomnumber) * 235
                    snakeleft2 += Double(randomnumber) * 235
                    snakeleft3 += Double(randomnumber) * 235
                    snakeleft4 += Double(randomnumber) * 235
                    //maybe adjust later
                    //disabledx = leafpaddingx * 2
                    
                }
                
            }
            .buttonStyle(.bordered)
            .tint(lightGreen)
            .offset(y:400)
            .offset(x:-100)
            .disabled(positionx == -6)
            Button("Up") { 
                
                withAnimation {
                    randomnumber = 1
                    spacesmovedupfloat += Double(randomnumber) * 235
                    positiony = positiony + 1
                    snakeup += Double(randomnumber) * 235
                    snakeup2 += Double(randomnumber) * 235
                    snakeup3 += Double(randomnumber) * 235
                    snakeup4 += Double(randomnumber) * 235
                    //disabledy = leafpaddingy * 2
                    
                    
                }
                
            }
            .buttonStyle(.bordered)
            .tint(lightGreen)
            .offset(y:315)
            .offset(x:0)
            .disabled(positiony == 2)
            
            Button("Down") { 
                
                withAnimation {
                    randomnumber = 1
                    spacesmoveddownfloat += Double(randomnumber) * 235
                    positiony = positiony - 1
                    snakedown += Double(randomnumber) * 235
                    snakedown2 += Double(randomnumber) * 235
                    snakedown3 += Double(randomnumber) * 235
                    snakedown4 += Double(randomnumber) * 235
                    //disabledy = leafpaddingy * 2
                    
                    
                }
                
            }
            .buttonStyle(.bordered)
            .tint(lightGreen)
            .offset(y:485)
            .offset(x: 0)
            .disabled(positiony == 0)
            
            Image(systemName: "arrow.up.and.down.and.arrow.left.and.right")
                .resizable()
                .frame(maxWidth: 100, maxHeight: 100)
                .aspectRatio(1, contentMode: .fit)
                .foregroundStyle(outlineColor)
                .padding(.init(top: 800, leading: 0, bottom: 0, trailing: 0))
                .foregroundStyle(Color.white)
            
            VStack{
                Image(snakesprout)
                    .resizable()
                    .frame(width: 200, height: 200)
                    .foregroundStyle(.red)
                    .padding(.init(top: spacesmoveddownfloat, leading: spacesmovedrightfloat, bottom: spacesmovedupfloat, trailing: spacesmovedleftfloat))
            }
            VStack{
                Image(snakewink)
                    .resizable()
                    .frame(width: 150, height: 150)
                    .foregroundStyle(.red)
                    .padding(.init(top: snakedown, leading: snakeright, bottom: snakeup, trailing: snakeleft))
                    .opacity(snakevalue2)
            }
            VStack{
                Image(snakewink)
                    .resizable()
                    .frame(width: 150, height: 150)
                    .foregroundStyle(.red)
                    .padding(.init(top: snakedown2, leading: snakeright2, bottom: snakeup2, trailing: snakeleft2))
                    .opacity(snakevalue3)
            }
            VStack{
                Image(snakewink)
                    .resizable()
                    .frame(width: 150, height: 150)
                    .foregroundStyle(.red)
                    .padding(.init(top: snakedown3, leading: snakeright3, bottom: snakeup3, trailing: snakeleft3))
                    .opacity(snakevalue4)
            }
            VStack{
                Image(snakewink)
                    .resizable()
                    .frame(width: 150, height: 150)
                    .foregroundStyle(.red)
                    .padding(.init(top: snakedown4, leading: snakeright4, bottom: snakeup4, trailing: snakeleft4))
                    .opacity(snakevalue5)
            }
            VStack{
                Image(snakewink)
                    .resizable()
                    .frame(width: 150, height: 150)
                    .foregroundStyle(.red)
                    .padding(.init(top: snakedown5, leading: snakeright5, bottom: snakeup5, trailing: snakeleft5))
                    .opacity(snakevalue6)
            }
            VStack {
                Image("Sprout")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .foregroundStyle(.green)
                    .offset(x:leafpaddingxfloat)
                    .offset(y:leafpaddingyfloat)
                    .opacity(sproutopacity)
                //.padding(.init(top: 0, leading: leafpaddingxfloat, bottom: leafpaddingyfloat, trailing: 0))
                //DID NOT WORK FIX
                
                
                
            }
            VStack {
                Text(acornsstring)
                    .padding(.init(top: 700, leading: 450, bottom: 0, trailing: 0))
                    .foregroundStyle(outlineColor)
                    .font(.largeTitle)
            }
            
            VStack {
                Text(congrats)
                    .font(.largeTitle.lowercaseSmallCaps()
                        .italic())
                    .foregroundStyle(outlineColor)
                    .padding(.init(top: 0, leading: 0, bottom: 800, trailing: 0))
                
                Button("Play Again!") {
                    acorns = 0
                    creature = "Creature"
                    outfit = "Hat"
                    spacesmoveddownfloat = 0
                    spacesmovedupfloat = 0
                    spacesmovedleftfloat = 0
                    spacesmovedrightfloat = 0
                    leafpaddingxfloat = 0
                    leafpaddingyfloat = 0
                    congrats = "Can you help me grow my cat train and grow my sprout? I need to collect 4!"
                    acornsstring = "0"
                    disabledx = 0
                    disabledy = 0
                    positionx = 0
                    positiony = 0
                    leafpaddingy = 0
                    leafpaddingx = 0
                    acorn2 = 0
                    acornsstring = "0"
                    snakeleft = 400
                    snakeleft2 = 800
                    snakeleft3 = 1200
                    snakeleft4 = 1600
                    snakeleft5 = 2000
                    snakeright = 0
                    snakeright2 = 0
                    snakeright3 = 0
                    snakeright4 = 0
                    snakeright5 = 0
                    snakeup = 0
                    snakeup2 = 0
                    snakeup3 = 0
                    snakeup4 = 0
                    snakeup5 = 0
                    snakedown = 0
                    snakedown2 = 0
                    snakedown3 = 0
                    snakedown4 = 0
                    snakedown5 = 0
                    snakevalue1 = 1
                    snakevalue2 = 0
                    snakevalue3 = 0
                    snakevalue4 = 0
                    snakevalue5 = 0
                    snakevalue6 = 0
                    snakevalue1int = 1
                    snakevalue2int = 0
                    snakevalue3int = 0
                    snakevalue4int = 0
                    snakevalue5int = 0
                    snakevalue6int = 0
                    snake1pos = 0
                    sproutopacity = 1
                    snakewink = "Snake"
                    snakesprout = "Snake"
                    
                }
                .buttonStyle(.bordered)
                .tint(lightGreen)
                .disabled(acorns < 4)
                .offset(y:-800)
                
            }
        }
    }
}

#Preview {
    Snake2()
}


