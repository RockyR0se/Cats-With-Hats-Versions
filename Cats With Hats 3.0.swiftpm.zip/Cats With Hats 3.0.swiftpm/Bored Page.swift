import SwiftUI

struct BoredPage: View {
    var body: some View {
        ZStack {
            Color(darkGreen)
            VStack {
                Text("That's okay! If you have a peice of technology nearby, try going to something like the bored button. If not, try doing something new, like if your not really a drawer maybe try drawing a picture of someone.")
                    .bold()
                    .font(.title2)
                    .multilineTextAlignment(.center)
            }
        }
    }
}

#Preview {
    BoredPage()
}

