import SwiftUI

struct TicTacToePage: View {
    @State public var numberOfPips: Int = 1
    @State public var turn: Int = 1
    @State public var numberOfPipsstring: String = ""
    @State public var textturn: String = "Cross' turn!"
    @State public var fiveN: Double = 0
    @State public var fiveC: Double = 0
    @State public var twoN: Double = 0   
    @State public var twoC: Double = 0
    @State public var oneN: Double = 0
    @State public var oneC: Double = 0
    @State public var threeN: Double = 0
    @State public var threeC: Double = 0
    @State public var fourN: Double = 0
    @State public var fourC: Double = 0
    @State public var sixN: Double = 0
    @State public var sixC: Double = 0
    @State public var sevenN: Double = 0
    @State public var sevenC: Double = 0
    @State public var eightN: Double = 0
    @State public var eightC: Double = 0
    @State public var nineN: Double = 0
    @State public var nineC: Double = 0
    @State public var reroll: String = ""
    @State public var one: Int = 0
    @State public var two: Int = 0
    @State public var three: Int = 0
    @State public var four: Int = 0
    @State public var five: Int = 0
    @State public var six: Int = 0
    @State public var seven: Int = 0
    @State public var eight: Int = 0
    @State public var nine: Int = 0
    @State public var rerollopacity: Int = 0
    
    
    
    var body: some View {
        ZStack {
            
            Color(darkGreen)
            VStack {
                Text(textturn)
                    .font(.largeTitle.lowercaseSmallCaps()
                        .italic())
                    .foregroundStyle(outlineColor)
                    .padding(.init(top: 0, leading: 0, bottom: 800, trailing: 0))
            }
            VStack {
                Text("Reroll if it dosen't appear!")
                    .font(.largeTitle.lowercaseSmallCaps()
                        .italic())
                    .foregroundStyle(outlineColor)
                    .padding(.init(top: 900, leading: 0, bottom: 0, trailing: 0))
                    
            }
            VStack {
                Image("TicTacToeBoard")
                    .resizable()
                    .frame(width: 600, height: 600)
            }
            VStack {
                Image("Noughts")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .opacity(fiveN)
                //5 nought
                
            }
            VStack {
                Image("Crosses")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .opacity(fiveC)
                //5 cross
            }
            VStack {
                Image("Noughts")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 0, leading: 0, bottom: 400, trailing: 0))
                    .opacity(twoN)
                //2 nought
            }
            VStack {
                Image("Crosses")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 0, leading: 0, bottom: 400, trailing: 0))
                    .opacity(twoC)
                //2 cross
            }
            VStack {
                Image("Noughts")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 0, leading: 0, bottom: 400, trailing: 400))
                    .opacity(oneN)
                //1 noughts
            }
            VStack {
                Image("Crosses")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 0, leading: 0, bottom: 400, trailing: 400))
                    .opacity(oneC)
                //1 cross
            }
            VStack {
                Image("Noughts")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 0, leading: 400, bottom: 400, trailing: 0))
                    .opacity(threeN)
                //3 noughts
            }
            VStack {
                Image("Crosses")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 0, leading: 400, bottom: 400, trailing: 0))
                    .opacity(threeC)
                //3 cross
            }
            VStack {
                Image("Noughts")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 0, leading: 0, bottom: 0, trailing: 400))
                    .opacity(fourN)
                //4 noughts
            }
            VStack {
                Image("Crosses")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 0, leading: 0, bottom: 0, trailing: 400))
                    .opacity(fourC)
                //4 cross
            }
            VStack {
                Image("Noughts")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 0, leading: 400, bottom: 0, trailing: 0))
                    .opacity(sixN)
                //6 nought
            }
            VStack {
                Image("Crosses")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 0, leading: 400, bottom: 0, trailing: 0))
                    .opacity(sixC)
            }
            VStack {
                Image("Noughts")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 400, leading: 0, bottom: 0, trailing: 400))
                    .opacity(sevenN)
                //7 noughts
            }
            VStack {
                Image("Crosses")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 400, leading: 0, bottom: 0, trailing: 400))
                    .opacity(sevenC)
                //7 noughts
            }
            VStack {
                Image("Noughts")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 400, leading: 0, bottom: 0, trailing: 0))
                    .opacity(eightN)
                //8 noughts
            }
            VStack {
                Image("Crosses")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 400, leading: 0, bottom: 0, trailing: 0))
                    .opacity(eightC)
                //8 cross
            }
            VStack {
                Image("Noughts")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 400, leading: 400, bottom: 0, trailing: 0))
                    .opacity(nineN)
                //9 noughts
            }
            VStack {
                Image("Crosses")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 400, leading: 400, bottom: 0, trailing: 0))
                    .opacity(nineC)
                //9 crosses
            }
            VStack {
                Button("Roll") { 
                    
                    withAnimation {
                        numberOfPips = Int.random(in: 1...9)
                        numberOfPipsstring = String(numberOfPips)
                        if turn == 1 {
                            if numberOfPips == 1 {
                                if oneC != 1 {
                                    if oneN != 1 {
                                        if one == 0 {
                                            oneC = 1
                                            one = one + 1
                                        } else {
                                            reroll = "Reroll!"
                                        }
                                       
                                        if turn == 1 {
                                            turn = 2
                                            textturn = "Nought's turn!"
                                            
                                        } else {
                                            turn = 1
                                            textturn = "Cross' turn!"
                                        }
                                    }
                                } 
                                
                                
                            }
                            if numberOfPips == 2 {
                                if twoC != 1 {
                                    if twoN != 1 {
                                        if two == 0 {
                                            twoC = 1
                                            two = two + 1
                                        } else {
                                            reroll = "Reroll!"
                                        }
                                        if turn == 1 {
                                            turn = 2
                                            textturn = "Nought's turn!"
                                            
                                        } else {
                                            turn = 1
                                            textturn = "Cross' turn!"
                                        }
                                    }
                                } 
                            }
                            if numberOfPips == 3 {
                                if threeC != 1 {
                                    if threeN != 1 {
                                        if three == 0 {
                                            threeC = 1
                                            three = three + 1
                                        } else {
                                            reroll = "Reroll!"
                                        }
                                        if turn == 1 {
                                            turn = 2
                                            textturn = "Nought's turn!"
                                            
                                        } else {
                                            turn = 1
                                            textturn = "Cross' turn!"
                                        }
                                    }
                                } 
                            }
                            if numberOfPips == 4 {
                                if fourC != 1 {
                                    if fourN != 1 {
                                        if four == 0 {
                                            fourC = 1
                                            four = four + 1
                                        } else {
                                            reroll = "Reroll!"
                                        }
                                        if turn == 1 {
                                            turn = 2
                                            textturn = "Nought's turn!"
                                            
                                        } else {
                                            turn = 1
                                            textturn = "Cross' turn!"
                                        }
                                    }
                                } 
                            }
                            if numberOfPips == 5 {
                                if fiveC != 1 {
                                    if fiveN != 1 {
                                        if five == 0 {
                                            fiveC = 1
                                            five = five + 1
                                        } else {
                                            reroll = "Reroll!"
                                        }
                                        if turn == 1 {
                                            turn = 2
                                            textturn = "Nought's turn!"
                                            
                                        } else {
                                            turn = 1
                                            textturn = "Cross' turn!"
                                        }
                                    }
                                } 
                            }
                            if numberOfPips == 6 {
                                if sixC != 1 {
                                    if sixN != 1 {
                                        if six == 0 {
                                            sixC = 1
                                            six = six + 1
                                        } else {
                                            reroll = "Reroll!"
                                        }
                                        if turn == 1 {
                                            turn = 2
                                            textturn = "Nought's turn!"
                                            
                                        } else {
                                            turn = 1
                                            textturn = "Cross' turn!"
                                        }
                                    }
                                } 
                            }
                            if numberOfPips == 7 {
                                if sevenC != 1 {
                                    if sevenN != 1 {
                                        if seven == 0 {
                                            sevenC = 1
                                            seven = seven + 1
                                        } else {
                                            reroll = "Reroll!"
                                        }
                                        if turn == 1 {
                                            turn = 2
                                            textturn = "Nought's turn!"
                                            
                                        } else {
                                            turn = 1
                                            textturn = "Cross' turn!"
                                        }
                                    }
                                } 
                            }
                            if numberOfPips == 8 {
                                if eightC != 1 {
                                    if eightN != 1 {
                                        if eight == 0 {
                                            eightC = 1
                                            eight = eight + 1
                                        } else {
                                            reroll = "Reroll!"
                                        }
                                        if turn == 1 {
                                            turn = 2
                                            textturn = "Nought's turn!"
                                            
                                        } else {
                                            turn = 1
                                            textturn = "Cross' turn!"
                                        }
                                    }
                                } 
                            }
                            if numberOfPips == 9 {
                                if nineC != 1 {
                                    if nineN != 1 {
                                        if nine == 0 {
                                            nineC = 1
                                            nine = nine + 1
                                        } else {
                                            reroll = "Reroll!"
                                        }
                                        if turn == 1 {
                                            turn = 2
                                            textturn = "Nought's turn!"
                                            
                                        } else {
                                            turn = 1
                                            textturn = "Cross' turn!"
                                        }
                                    }
                                } 
                            }
                        }
                        if turn == 2 {
                            if numberOfPips == 1 {
                                if oneC != 1 {
                                    if oneN != 1 {
                                        if one == 0 {
                                            oneN = 1
                                            one = one + 1
                                        } else {
                                            reroll = "Reroll!"
                                        }
                                        
                                        if turn == 1 {
                                            turn = 2
                                            textturn = "Nought's turn!"
                                            
                                        } else {
                                            turn = 1
                                            textturn = "Cross' turn!"
                                        }
                                    }
                                } 
                                
                                
                            }
                            if numberOfPips == 2 {
                                if twoC != 1 {
                                    if twoN != 1 {
                                        if two == 0 {
                                            twoN = 1
                                            two = two + 1
                                        } else {
                                            reroll = "Reroll!"
                                        }
                                        if turn == 1 {
                                            turn = 2
                                            textturn = "Nought's turn!"
                                            
                                        } else {
                                            turn = 1
                                            textturn = "Cross' turn!"
                                        }
                                    }
                                } 
                            }
                            if numberOfPips == 3 {
                                if threeC != 1 {
                                    if threeN != 1 {
                                        if three == 0 {
                                            threeN = 1
                                            three = three + 1
                                        } else {
                                            reroll = "Reroll!"
                                        }
                                        if turn == 1 {
                                            turn = 2
                                            textturn = "Nought's turn!"
                                            
                                        } else {
                                            turn = 1
                                            textturn = "Cross' turn!"
                                        }
                                    }
                                } 
                            }
                            if numberOfPips == 4 {
                                if fourC != 1 {
                                    if fourN != 1 {
                                        if four == 0 {
                                            fourN = 1
                                            four = four + 1
                                        } else {
                                            reroll = "Reroll!"
                                        }
                                        if turn == 1 {
                                            turn = 2
                                            textturn = "Nought's turn!"
                                            
                                        } else {
                                            turn = 1
                                            textturn = "Cross' turn!"
                                        }
                                    }
                                } 
                            }
                            if numberOfPips == 5 {
                                if fiveC != 1 {
                                    if fiveN != 1 {
                                        if five == 0 {
                                            fiveN = 1
                                            five = five + 1
                                        } else {
                                            reroll = "Reroll!"
                                        }
                                        if turn == 1 {
                                            turn = 2
                                            textturn = "Nought's turn!"
                                            
                                        } else {
                                            turn = 1
                                            textturn = "Cross' turn!"
                                        }
                                    }
                                } 
                            }
                            if numberOfPips == 6 {
                                if sixC != 1 {
                                    if sixN != 1 {
                                        if six == 0 {
                                            sixN = 1
                                            six = six + 1
                                        } else {
                                            reroll = "Reroll!"
                                        }
                                        if turn == 1 {
                                            turn = 2
                                            textturn = "Nought's turn!"
                                            
                                        } else {
                                            turn = 1
                                            textturn = "Cross' turn!"
                                        }
                                    }
                                } 
                            }
                            if numberOfPips == 7 {
                                if sevenC != 1 {
                                    if sevenN != 1 {
                                        if seven == 0 {
                                            sevenN = 1
                                            seven = seven + 1
                                        } else {
                                            reroll = "Reroll!"
                                        }
                                        if turn == 1 {
                                            turn = 2
                                            textturn = "Nought's turn!"
                                            
                                        } else {
                                            turn = 1
                                            textturn = "Cross' turn!"
                                        }
                                    }
                                } 
                            }
                            if numberOfPips == 8 {
                                if eightC != 1 {
                                    if eightN != 1 {
                                        if eight == 0 {
                                            eightN = 1
                                            eight = eight + 1
                                        } else {
                                            reroll = "Reroll!"
                                        }
                                        if turn == 1 {
                                            turn = 2
                                            textturn = "Nought's turn!"
                                            
                                        } else {
                                            turn = 1
                                            textturn = "Cross' turn!"
                                        }
                                    }
                                } 
                            }
                            if numberOfPips == 9 {
                                if nineC != 1 {
                                    if nineN != 1 {
                                        if nine == 0 {
                                            nineN = 1
                                            nine = nine + 1
                                        } else {
                                            reroll = "Reroll!"
                                        }
                                        if turn == 1 {
                                            turn = 2
                                            textturn = "Nought's turn!"
                                            
                                        } else {
                                            turn = 1
                                            textturn = "Cross' turn!"
                                        }
                                    }
                                } 
                            }
                        }
                        //reroll text not working
                        
                        
                        
                        
                        
                        
                    }
                    
                }
                .buttonStyle(.bordered)
                .tint(lightGreen)
                .offset(y:800)
                Text("\(numberOfPipsstring)")
                    .font(.largeTitle.lowercaseSmallCaps()
                    .italic())
                    .foregroundStyle(outlineColor)
                    .padding(.init(top: 800, leading: 0, bottom: 0, trailing: 0))
                    
                
            }
        }
    }
}
#Preview {
    TicTacToePage()
}

