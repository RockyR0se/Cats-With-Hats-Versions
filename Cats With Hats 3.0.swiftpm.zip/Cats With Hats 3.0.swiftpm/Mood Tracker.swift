import SwiftUI

struct HowAreYouFeelingPage: View {
    @State public var dayofweek: String = ""
    @State public var emotion: String = ""
    var body: some View {
        NavigationStack {
            ZStack {
                Color(darkGreen)
                VStack {
                    Text("How Are You Feeling Today?")
                        .bold()
                        .font(.title)
                        .padding(.init(top: 0, leading: 0, bottom: 750, trailing: 0))
                        .foregroundStyle(outlineColor)
                }
                VStack {
                    Image("Happy Cat")
                        .resizable()
                        .frame(width: 200, height: 200)
                        .padding(.init(top: 0, leading: 0, bottom: 400, trailing: 200))
                }
                VStack {
                    Image("Bored Cat")
                        .resizable()
                        .frame(width: 200, height: 200)
                        .padding(.init(top: 0, leading: 200, bottom: 400, trailing: 0))
                }
                VStack {
                    Image("Sad Cat")
                        .resizable()
                        .frame(width: 200, height: 200)
                        .padding(.init(top: 0, leading: 0, bottom: 100, trailing: 0))
                }
                VStack {
                    Button("Monday") {
                        dayofweek = "Monday"
                    }
                    
                    .bold()
                    .font(.title2)
                    .padding(.init(top:200, leading: 0, bottom: 0, trailing: 200))
                    .buttonStyle(.bordered)
                    .tint(lightGreen)
                }
                VStack {
                    Button("Tuesday") {
                        dayofweek = "Tuesday"
                    }
                    
                    .bold()
                    .font(.title2)
                    .padding(.init(top:200, leading: 200, bottom: 0, trailing: 0))
                    .buttonStyle(.bordered)
                    .tint(lightGreen)
                }
                VStack {
                    Button("Wednesday") {
                        dayofweek = "Wednesday"
                    }
                    
                    .bold()
                    .font(.title2)
                    .padding(.init(top:300, leading: 0, bottom: 0, trailing: 200))
                    .buttonStyle(.bordered)
                    .tint(lightGreen)
                }
                VStack {
                    Button("Thursday") {
                        dayofweek = "Thursday"
                    }
                    
                    .bold()
                    .font(.title2)
                    .padding(.init(top:300, leading: 200, bottom: 0, trailing: 0))
                    .buttonStyle(.bordered)
                    .tint(lightGreen)
                }
                VStack {
                    Button("Friday") {
                        dayofweek = "Friday"
                    }
                    
                    .bold()
                    .font(.title2)
                    .padding(.init(top:400, leading: 0, bottom: 0, trailing: 200))
                    .buttonStyle(.bordered)
                    .tint(lightGreen)
                }
                VStack {
                    Button("Saturday") {
                        dayofweek = "Saturday"
                    }
                    
                    .bold()
                    .font(.title2)
                    .padding(.init(top:400, leading: 200, bottom: 0, trailing: 0))
                    .buttonStyle(.bordered)
                    .tint(lightGreen)
                }
                VStack {
                    Button("Sunday") {
                        dayofweek = "Sunday"
                    }
                    
                    .bold()
                    .font(.title2)
                    .padding(.init(top:500, leading: 0, bottom: 0, trailing: 0))
                    .buttonStyle(.bordered)
                    .tint(lightGreen)
                }
                VStack {
                    Button("Happy") {
                        emotion = "Happy"
                        NavigationLink(destination: HappyPage()) {
                            
                            Text("Happy")
                                .bold()
                                .font(.title2)
                            
                            
                                .cornerRadius(10)
                        }
                        
                    } .padding(.init(top: 0, leading: 0, bottom: 250, trailing: 210))
                        .buttonStyle(.bordered)
                        .tint(lightGreen)
                    
                }
                VStack {
                    Button("Bored") {
                        emotion = "Bored"
                        NavigationLink(destination: BoredPage()) {
                            Text("Bored")
                                .bold()
                                .font(.title2)
                            
                            
                                .cornerRadius(10)
                        }
                        
                    }.padding(.init(top: 0, leading: 200, bottom: 250, trailing: 0))
                        .buttonStyle(.bordered)
                        .tint(lightGreen)
                    
                    
                }
                VStack {
                    Button("Sad") {
                        emotion = "Sad"
                        NavigationLink(destination: SadPage()) {
                            Text("Sad")
                                .bold()
                                .font(.title2)
                            
                            
                                .cornerRadius(10)
                        }
                        
                    }.padding(.init(top: 50, leading: 0, bottom: 0, trailing: 0))
                        .buttonStyle(.bordered)
                        .tint(lightGreen)
                    
                }
                VStack {
                    Text("On")
                        .bold()
                        .font(.title3)
                        .foregroundStyle(outlineColor)
                        .padding(.init(top:700, leading: 0, bottom: 0, trailing: 400))
                }
                VStack {
                    Text(dayofweek)
                        .bold()
                        .font(.title3)
                        .foregroundStyle(outlineColor)
                        .padding(.init(top:700, leading: 0, bottom: 0, trailing: 250))
                }
                VStack {
                    Text("you were feeling")
                        .bold()
                        .font(.title3)
                        .foregroundStyle(outlineColor)
                        .padding(.init(top:700, leading: 100, bottom: 0, trailing: 0))
                }
                VStack {
                    Text(emotion)
                        .bold()
                        .font(.title3)
                        .foregroundStyle(outlineColor)
                        .padding(.init(top:700, leading: 350, bottom: 0, trailing: 0))
                }

            
            
                    
                    
                
            }
        }
    }
}
#Preview {
    HowAreYouFeelingPage()
}

//fix navigation links
