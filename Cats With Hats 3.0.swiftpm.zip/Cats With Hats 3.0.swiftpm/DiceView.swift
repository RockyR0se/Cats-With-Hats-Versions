import SwiftUI

struct DiceView: View {
    
    @State public var numberOfPips: Int = 1
    @State public var spacesmoved: Int = 0
    @State public var spacesmovedfloat: Double = -280
    @State public var activity: String = ""
    @State public var activitynumber: Int = 0
    @State public var sparkles: Int = 0
    @State public var sparklesstring: String = "0"    
    var body: some View {
        let sparklesstring = String(sparkles)
        ZStack {
            Text(sparklesstring)
                .padding(.init(top: 900, leading: 600, bottom: 0, trailing: 0))
                .foregroundStyle(lightGreen)
            Image(systemName: "sparkles")
                .padding(.init(top: 900, leading: 570, bottom: 0, trailing: 0))
                .foregroundStyle(lightGreen)
        }
        
        
        if activitynumber == 1 {
            Text("Put on your comfort song! Relax and listen to the soothing beats. Try and focus in one of the specific beats of the song, it will help focus and calm your mind. For example say the song has both guitar and drums, choose to either count the beats to one of those instruments instead of switching between both.")
                .font(.title2)
                .foregroundStyle(outlineColor)
                .padding(.init(top: 0, leading: 200, bottom: 500, trailing: 200))
                .multilineTextAlignment(.center)
            Button("Done") { 
                activitynumber = 0
                spacesmovedfloat = -280
                sparkles = sparkles + 1
            }
            
            .offset(y: 150) //might change later
            .tint(lightGreen)
            .buttonStyle(.bordered)
        }
        if activitynumber == 2 {
            Text("Go or look outside! Go for a walk in your favourite area, try to not go near any busy roads, just go in a nice quiet area, put some music on, take some photos of nature and relax! Or if you don't want or don't feel ready to go outside, look out the window, maybe sketch the view of your garden from the window.")
                .font(.title2)
                .foregroundStyle(outlineColor)
                .padding(.init(top: 0, leading: 200, bottom: 500, trailing: 200))
                .multilineTextAlignment(.center)
            Button("Done") { 
                activitynumber = 0
                spacesmovedfloat = -280
                sparkles = sparkles + 1
            }
            
            .offset(y: 150) //might change later
            .tint(lightGreen)
            .buttonStyle(.bordered)
        }
        if activitynumber == 3 {
            Text("Go and make or buy your favourite drink! Make yourself something nice, whether its a cozy hot chocolate, or a glass of juice! Or even go for a nice relaxing walk and stop buy a cafe to buy something.")
                .font(.title2)
                .foregroundStyle(outlineColor)
                .padding(.init(top: 0, leading: 200, bottom: 500, trailing: 200))
                .multilineTextAlignment(.center)
            Button("Done") { 
                activitynumber = 0
                spacesmovedfloat = -280
                sparkles = sparkles + 1
            }
            
            .offset(y: 150) //might change later
            .tint(lightGreen)
            .buttonStyle(.bordered)
        }
        if activitynumber == 4 {
            Text("Text or say something nice to someone! Whether this is a friend or family member, just drop them a text or tell them something nice, as it can make you feel a lot better boosting someone else up! Maybe tell a friend how grateful you are to have them, or send a cute picture of a cat to light up their mood!")
                .font(.title2)
                .foregroundStyle(outlineColor)
                .padding(.init(top: 0, leading: 300, bottom: 500, trailing: 300))
                .multilineTextAlignment(.center)
            Button("Done") { 
                activitynumber = 0
                spacesmovedfloat = -280
                sparkles = sparkles + 1
            }
            
            .offset(y: 150) //might change later
            .tint(lightGreen)
            .buttonStyle(.bordered)
        }
        if activitynumber == 5 {
            Text("Write down some things your grateful for or draw a cute picture! Maybe you'll write down some things in your life that happened recently that made you happy, or draw a picture of your favourite character!")
                .font(.title2)
                .foregroundStyle(outlineColor)
                .padding(.init(top: 0, leading: 500, bottom: 500, trailing: 500))
                .multilineTextAlignment(.center)
            Button("Done") { 
                activitynumber = 0
                spacesmovedfloat = -280
                sparkles = sparkles + 1
            }
            
            .offset(y: 150) //might change later
            .tint(lightGreen)
            .buttonStyle(.bordered)
        }
        VStack {
            Button("Roll") { 
                
                withAnimation {
                    numberOfPips = Int.random(in: 1...5)
                    spacesmovedfloat += Double(numberOfPips) * 235
                    activitynumber = numberOfPips
                    
                }
                
            }
            .buttonStyle(.bordered)
            .tint(lightGreen)
            .disabled(activitynumber > 0)
            .offset(y:800)
            Image(systemName: "die.face.\(numberOfPips)")
                .resizable()
                .frame(maxWidth: 100, maxHeight: 100)
                .aspectRatio(1, contentMode: .fit)
                .foregroundStyle(outlineColor)
                .padding(.init(top: 800, leading: 0, bottom: 0, trailing: 0))
                .foregroundStyle(Color.white)
            
            
            Image(systemName: "cat")
                .resizable()
                .frame(width: 100, height: 100)
                .foregroundStyle(lightGreen)
                .padding(.init(top: -500, leading: spacesmovedfloat, bottom: 0, trailing: 300))
            
        }
        
        
    }
}




#Preview {
    DiceView()
}


