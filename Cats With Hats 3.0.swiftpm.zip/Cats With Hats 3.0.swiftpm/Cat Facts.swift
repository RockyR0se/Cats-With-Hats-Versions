import SwiftUI

struct CatFactsPage: View {
    @State public var fact1: String = "Cat's whiskers are mood indicators. If they hang down relaxed, the cat is satisfied. If they are facing straight ahead, they may be angry."
    @State public var fact2: String = "Cats mark their owners as possessions. They have scent glands in their cheeks, paws and flanks. When they rub against their human with it, they leave a message for other cats that they have claimed their owners."
    @State public var fact3: String = "White cats with blue eyes are prone to deafness. The cause is an anomaly in their genetic make-up."
    @State public var fact1randomise: Int = 0
    @State public var fact2randomise: Int = 0
    @State public var fact3randomise: Int = 0
    var body: some View {
        ZStack {
            Color(darkGreen)
            VStack {
                Text("Cat Facts!")
                    .bold()
                    .font(.largeTitle)
                    .padding(.init(top: 0, leading: 0, bottom: 600, trailing: 0))
            }
            VStack {
                Text("Fact Number #1!")
                    .bold()
                    .font(.title2)
                    .padding(.init(top: 0, leading: 0, bottom: 450, trailing: 0))
            }
            VStack {
                Text(fact1)
                    .bold()
                    .padding(.init(top: 0, leading: 50, bottom: 350, trailing: 50))
                    .multilineTextAlignment(.center)
            }
            VStack {
                Text("Fact Number #2!")
                    .bold()
                    .font(.title2)
                    .padding(.init(top: 0, leading: 0, bottom: 200, trailing: 0))
            }
            VStack {
                Text(fact2)
                    .bold()
                    .padding(.init(top: 0, leading: 50, bottom: 75, trailing: 50))
                    .multilineTextAlignment(.center)
            }
            VStack {
                Text("Fact Number #3!")
                    .bold()
                    .font(.title2)
                    .padding(.init(top: 100, leading: 0, bottom: 0, trailing: 0))
            }
            VStack {
                Text(fact3)
                    .bold()
                    .padding(.init(top: 250, leading: 50, bottom: 0, trailing: 50))
                    .multilineTextAlignment(.center)
            }
            VStack {
                Button("Randomise Facts!") {
                    
                    fact1randomise = Int.random(in: 1...11)
                    fact2randomise = Int.random(in: 1...11)
                    fact3randomise = Int.random(in: 1...11)
                    if fact1randomise == 1 {
                        fact1 = "Cat's whiskers are mood indicators. If they hang down relaxed, the cat is satisfied. If they are facing straight ahead, they may be angry."
                    }
                    if fact1randomise == 2 {
                        fact1 = "Cats walk like camels and giraffes: They move both of their right feet first, then move both of their left feet. No other animals walk this way."
                    }
                    if fact1randomise == 3 {
                        fact1 = "When a cat flops over and exposes his belly, it’s not always an invitation for a belly rub. A cat does this when they're relaxed and showing trust."
                    }
                    if fact1randomise == 4 {
                        fact1 = "A cat has two vocal cords and can make over 100 sounds."
                    }
                    if fact1randomise == 5 {
                        fact1 = "A cats feild of vision is about 130 degrees."
                    }
                    if fact1randomise == 6 {
                        fact1 = "Cats’ collarbones don’t connect to their other bones, as these bones are buried in their shoulder muscles."
                    }
                    if fact1randomise == 7 {
                        fact1 = "If you keep your cat active during the day, he will sleep better at night. If you’re not free-feeding your cat, you can also help her get a good night’s sleep by providing her with a substantial evening meal."
                    }
                    if fact1randomise == 8 {
                        fact1 = "A cat’s purr vibrates at a frequency of 25 to 150 hertz, which is the same frequency at which muscles and bones repair themselves."
                    }
                    if fact1randomise == 9 {
                        fact1 = "The average age for an indoor cat is 15 years while the average age for an outdoor cat is only 3-5 years."
                    }
                    if fact1randomise == 10 {
                        fact1 = "Cats spend between 30 to 50 percent of their day grooming themselves."
                    }
                    if fact1randomise == 11 {
                        fact1 = "Cats are nearsighted, but their peripheral vision and night vision are far superior compared to humans."
                    }
                    if fact2randomise == 1 {
                        fact2 = "Cats mark their owners as possessions. They have scent glands in their cheeks, paws and flanks. When they rub against their human with it, they leave a message for other cats that they have claimed their owners."
                    }
                    if fact2randomise == 2 {
                        fact2 = "When dogs wag their tails, they may be expressing happiness. But this isn’t the case for cats! When your cat wags their tail, it’s their way of warning you that you are getting on their last nerve."
                    }
                    if fact2randomise == 3 {
                        fact2 = "Thieving behavior is not uncommon among cats. They will often grab objects like stuffed animals, feather dusters, and other things that remind them of prey."
                    }
                    if fact2randomise == 4 {
                        fact2 = "Cats see six times better in the dark and at night than humans."
                    }
                    if fact2randomise == 5 {
                        fact2 = "Abraham Lincoln kept three cats in the white house. After the civil war was over, Lincoln found 3 kittens whose mother had died and took them in as his own."
                    }
                    if fact2randomise == 6 {
                        fact2 = "Cats have an extra organ that allows them to taste scents on the air, which is why your cat stares at you with her mouth open from time to time."
                    }
                    if fact2randomise == 7 {
                        fact2 = "If cats are fighting, the cat that’s hissing is the more vulnerable one."
                    }
                    if fact2randomise == 8 {
                        fact2 = "There are about 88 million pet cats in the United States, which makes them the most popular pet in the country!"
                    }
                    if fact2randomise == 9 {
                        fact2 = "The largest breed of cat is the Ragdoll. Males weigh 12-20 pounds, with females weighing 10-15 pounds."
                    }
                    if fact2randomise == 10 {
                        fact2 = "House cats share 95.6% of their genetic makeup with tigers. You read that right, TIGERS. They also share some of the same behavior habits such as scent and urine marking, prey stalking and pouncing."
                    }
                    if fact2randomise == 11 {
                        fact2 = "Disneyland Resort in Anaheim, CA may be known as the “Happiest Place on Earth” but it’s also home to a squad of feral cats that freely roam around the theme park. Feral cats have been living at the Disneyland Resort for decades and are actually used to (ironically) help control the rodent population within the park."
                    }
                    if fact3randomise == 1 {
                        fact3 = "White cats with blue eyes are prone to deafness. The cause is an anomaly in their genetic make-up."
                    }
                    if fact3randomise == 2 {
                        fact3 = "According to Ancient History Encyclopedia, Herodotus wrote in 440BC that when a pet cat died in Ancient Egyptian times the family members would shave off their eyebrows in mourning. Now that’s an interesting cat fact!"
                    }
                    if fact3randomise == 3  {
                        fact3 = "Whether your Siamese kitten prints turn blond or brown in color is dependent on their body temperature. The Siamese cat carries albino genes which work at a body temperature of 36 Degrees Celsius."
                    }
                    if fact3randomise == 4 {
                        fact3 = "In just 10 years one female cat could produce around 49,000 kittens. Another reason to spay and neuter your pets and help support Trap-Neuter-Release programs."
                    }
                    if fact3randomise == 5 {
                        fact3 = "More than half of the world’s felines don’t respond to catnip. Scientists still don’t know quite why some kitties go crazy for the aromatic herb and others don’t, but they have figured out that catnip sensitivity is hereditary. If a kitten has one catnip-sensitive parent, there’s a one-in-two chance that it will also grow up to crave the plant. And if both parents react to 'nip, the odds increase to at least three in four."
                    }
                    if fact3randomise == 6 {
                        fact3 = "Cats’ purring may be a self-soothing behavior, since they make this noise when they’re ill or distressed, as well as when they’re happy."
                    }
                    if fact3randomise == 7 {
                        fact3 = "Cats are very fussy about their water bowls; some prefer to ignore their bowls entirely in favor of drinking from the sink faucet."
                    }
                    if fact3randomise == 8 {
                        fact3 = "Male cats are more likely to be left-pawed, while female cats are more likely to be right-pawed."
                    }
                    if fact3randomise == 9 {
                        fact3 = "A quivering cats tail is the greatest sign of love a cat can give you"
                    }
                    if fact3randomise == 10 {
                        fact3 = "Most cats have 18 toes, 5 on their front paws and 4 on their back paws. However, some cats can be born with “extra toes”, a condition called polydactylism."
                    }
                    if fact3randomise == 11 {
                        fact3 = "A female cat can become pregnant as young as 4 - 6 months of age. Spaying and neutering your cat around this age is the best way to prevent any unexpected litters and help reduce cat overpopulation."
                    }
                }
                .offset(y:250)
                .buttonStyle(.bordered)
                .tint(lightGreen)
            }
            VStack {
                Image("Mushroom4")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 975, leading: 0, bottom: 0, trailing: 500))
            }
            VStack {
                Image("Bored Cat")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 0, leading: 0, bottom: 1000, trailing: 200))
                    .rotationEffect(Angle(degrees: 45))
            }
            VStack {
                Image("Logo")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 0, leading: 0, bottom: 850, trailing: 0))
            }
            VStack {
                Image("Happy Cat")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 0, leading: 200, bottom: 1000, trailing: 0))
                    .rotationEffect(Angle(degrees: -45))
            }
        }
    }
}

#Preview {
    CatFactsPage()
}

