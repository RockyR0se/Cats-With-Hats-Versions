import SwiftUI

struct HappyPage: View {
    var body: some View {
        ZStack {
            Color(darkGreen)
            VStack {
                Text("Great Job! So what's making you happy? Try to remember that for when you're next stressed or sad.")
                    .bold()
                    .font(.title2)
                    .multilineTextAlignment(.center)
            }
            VStack {
                Image(systemName: "Mushroom4")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 0, leading: 0, bottom: 0, trailing: 0))
            }
        }
    }
}

#Preview {
    HappyPage()
}

