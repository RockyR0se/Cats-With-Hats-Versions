import SwiftUI

struct ContentView: View {
    var body: some View {
//        NavigationStack {
//            
//                    WelcomePage()
//                    
//                }
        TabView {
            
            WelcomePage()
                .tabItem {
                    Label("Home", systemImage: "house")
                    
                }
            CatFactsPage()
                .tabItem {
                    Label("Cat Facts", systemImage: "cat")
                }
            WarningPage()
                .tabItem {
                    Label("Warnings",systemImage:"exclamationmark.triangle")
                }
            ChooseIconPage()
                .tabItem {
                    Label("Icon", systemImage: "person")
                }
            HowAreYouFeelingPage()
                .tabItem {
                    Label("Mood Tracker", systemImage: "sun.max")
                }
            }
        
            
            }
            

        }
        
    


//https://www.tydac.ch/color/
