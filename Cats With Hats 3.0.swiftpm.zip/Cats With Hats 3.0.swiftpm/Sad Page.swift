import SwiftUI

struct SadPage: View {
    var body: some View {
        ZStack {
            Color(darkGreen)
            VStack {
                Text("What's making you sad? Is it something that someone said? If so, then maybe just leave them alone for a bit, they might not be feeling great themselves.")
                    .bold()
                    .font(.title2)
                    .multilineTextAlignment(.center)
            }
        }
    }
}

#Preview {
    SadPage()
}

