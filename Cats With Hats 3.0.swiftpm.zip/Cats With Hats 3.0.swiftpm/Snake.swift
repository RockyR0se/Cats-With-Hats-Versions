import SwiftUI

struct Movement2: View {
    
    @State public var randomnumber: Int = 1
    @State public var spacesmoved: Int = 0
    @State public var spacesmovedrightfloat: Double = 0
    @State public var spacesmovedleftfloat: Double = 0
    @State public var spacesmovedupfloat: Double = 0
    @State public var spacesmoveddownfloat: Double = 0
    @State public var positionx: Int = 0
    @State public var positiony: Int = 0
    @State public var positionxleaf: Int = 0
    @State public var positionyleaf: Int = 0
    @State public var acorns: Int = 0
    @State public var leafpaddingx: Int = 0
    @State public var leafpaddingy: Int = 0
    @State public var leafpaddingxfloat: Double = 0
    @State public var leafpaddingyfloat: Double = 0
    @State public var disabledx: Int = 0
    @State public var disabledy: Int = 0
    @State public var positionyfloat: Double = 0
    @State public var acornsstring: String = "0"
    @State public var snake: Int = -1
    @State public var secondhead: Int = 0
    @State public var secondheadfloat: Double = 0.00
    @State public var secondheadx: Int = 0
    @State public var secondheady: Int = 0
    @State public var secondheadrightfloat: Double = 0
    @State public var secondheadleftfloat: Double = 0
    @State public var secondheadupfloat: Double = 0
    @State public var secondheaddownfloat: Double = 0
    @State public var secondheadposition: Int = 0
    @State public var lefts: Int = 0
    @State public var rights: Int = 0
    //@State public var stretch: Double = 200
    
    var body: some View {
        let acornsstring = String(acorns)
        
        
        ZStack {
            Color(darkGreen)
                .ignoresSafeArea()
            Button("Collect") { 
                snake = snake + 1
                acorns = acorns + 1
                positionyfloat = Double(leafpaddingy)
                leafpaddingxfloat = 0
                leafpaddingyfloat = positionyfloat * 2
                //leafpaddingy = 0
                //positiony = leafpaddingy * 2 //fix this
                leafpaddingx = Int.random(in:-3...3)
                leafpaddingy = Int.random(in:0...1)
                leafpaddingxfloat += Double(leafpaddingx) * 235
                leafpaddingyfloat += Double(leafpaddingy) * -235
                //if leafpaddingy == 0 { //try put this in up down instead but mac said it didnt want to load :(
                //positiony = 0
                disabledy = leafpaddingy * 2
                disabledx = leafpaddingx * 2
                secondheadfloat = secondheadfloat + 1.00
                //stretch = stretch + 200

                
                
                
                
                
            }
            //disabledx = 100
            //disabledy = 100
            
            //make it so that it randomises every time the acorns is increased and that the collect button is disabled unless the cat has the same positionx and positiony as the acorn. make it so that the randomisation then converts to accurate padding positions aka. number of pips multiplied by 235, (470)
            
            //235 DID NOT WORK PLEASE FIX :((((
            .offset(y:250)
            .buttonStyle(.bordered)
            .tint(lightGreen)
            .disabled(disabledx != positionx || disabledy != positiony)
            
            
            
            Button("Right") { 
                
                withAnimation {
                    randomnumber = 1
                    spacesmovedrightfloat += Double(randomnumber) * 235
                    positionx = positionx + 1
                    rights = rights + 1
                    if rights >= 1 {
                        secondheadrightfloat = spacesmovedrightfloat - 400
                    }
                    
                    if lefts == 0{
                        secondheadrightfloat = spacesmovedrightfloat - 400
                        
                    } else {
                        secondheadrightfloat = spacesmovedrightfloat - 800
                        lefts = 0 
                    
                       
                        
                    }
                    
                    
                    //disabledx = leafpaddingx * 2
                    
                    
                }
                
            }
            .buttonStyle(.bordered)
            .tint(lightGreen)
            .offset(y:400)
            .offset(x:100)
            .disabled(positionx == 6)
            Button("Left") { 
                
                withAnimation {
                    randomnumber = 1
                    spacesmovedleftfloat += Double(randomnumber) * 235
                    positionx = positionx - 1
                    secondheadleftfloat = spacesmovedleftfloat - 400
                    lefts = lefts + 1
                    if lefts >= 1 {
                        secondheadleftfloat = spacesmovedleftfloat - 600
                    }
                    if rights == 0{
                        secondheadleftfloat = spacesmovedleftfloat - 400
                    
                    } else {
                        secondheadleftfloat = spacesmovedleftfloat - 800
                        rights = 0
                        
                        
                    }
                    
                    //disabledx = leafpaddingx * 2
                    
                }
                
            }
            .buttonStyle(.bordered)
            .tint(lightGreen)
            .offset(y:400)
            .offset(x:-100)
            .disabled(positionx == -6)
            Button("Up") { 
                
                withAnimation {
                    randomnumber = 1
                    spacesmovedupfloat += Double(randomnumber) * 235
                    positiony = positiony + 1
                    secondheadupfloat = spacesmovedupfloat - 400
                    //disabledy = leafpaddingy * 2
                    
                    
                }
                
            }
            .buttonStyle(.bordered)
            .tint(lightGreen)
            .offset(y:315)
            .offset(x:0)
            .disabled(positiony == 2)
            
            Button("Down") { 
                
                withAnimation {
                    randomnumber = 1
                    spacesmoveddownfloat += Double(randomnumber) * 235
                    positiony = positiony - 1
                    secondheaddownfloat = spacesmoveddownfloat - 400
                    //disabledy = leafpaddingy * 2
                    
                    
                }
                
            }
            .buttonStyle(.bordered)
            .tint(lightGreen)
            .offset(y:485)
            .offset(x: 0)
            .disabled(positiony == 0)
            
            Image(systemName: "arrow.up.and.down.and.arrow.left.and.right")
                .resizable()
                .frame(maxWidth: 100, maxHeight: 100)
                .aspectRatio(1, contentMode: .fit)
                .foregroundStyle(outlineColor)
                .padding(.init(top: 800, leading: 0, bottom: 0, trailing: 0))
                .foregroundStyle(Color.white)
            
            VStack{
                Image("squirrel")
                    .resizable()
                    .opacity(secondheadfloat)
                    .frame(width: 150, height: 150)
                    .foregroundStyle(.red)
                    .padding(.init(top: secondheaddownfloat, leading: secondheadrightfloat, bottom: secondheadupfloat, trailing: secondheadleftfloat))
                    
                     
            }
            
            VStack{
                Image("squirrel")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .foregroundStyle(.red)
                    .padding(.init(top: spacesmoveddownfloat, leading: spacesmovedrightfloat, bottom: spacesmovedupfloat, trailing: spacesmovedleftfloat))
                     
            }
            
            VStack {
                Image("Acorn")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .foregroundStyle(.green)
                    .offset(x:leafpaddingxfloat)
                    .offset(y:leafpaddingyfloat)
                //.padding(.init(top: 0, leading: leafpaddingxfloat, bottom: leafpaddingyfloat, trailing: 0))
                //DID NOT WORK FIX
                
                
                
            }
            
            VStack {
                Text(acornsstring)
                    .padding(.init(top: 900, leading: 600, bottom: 0, trailing: 0))
                    .foregroundStyle(darkGreen)
                    .font(.largeTitle)
            }
            
            
        }
    }
}
#Preview {
    Movement2()
}

//tomorrow make variable that switches left and right and detects what side it is on :3
