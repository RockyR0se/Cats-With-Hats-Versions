import SwiftUI

@main
struct MyApp: App {
    init() {
        let appearance = UITabBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = UIColor.white // Set your desired color
        
        UITabBar.appearance().standardAppearance = appearance
        UITabBar.appearance().scrollEdgeAppearance = appearance
    }
//stops the bar from changing. thanks chat gpt
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
