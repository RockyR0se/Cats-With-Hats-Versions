import SwiftUI

struct ChooseIconPage: View {
    @State public var iconCat: String = "CatWithHat"
    var body: some View {
        ZStack {
            Color(darkGreen)
            VStack {
                Text("Choose Your Cat")
                    .bold()
                    .font(.title)
                    .padding(.init(top: 450, leading: 0, bottom: 0, trailing: 0))
                    .foregroundStyle(outlineColor)
            }
            VStack {
                VStack {
                    Image("CatWithHat")
                        .resizable()
                        .frame(width: 250, height: 200)
                        .padding(.init(top: -220, leading: 0, bottom: 0, trailing: 200))
                    Button("Sprout Cat!") { 
                        iconCat = "CatWithHat"
                    }
                    .offset(x: -100) //might change later
                    .tint(lightGreen)
                    .buttonStyle(.bordered)
                }
                VStack {
                    Image("CatWithHat3")
                        .resizable()
                        .frame(width: 250, height: 200)
                        .padding(.init(top: -265, leading: 200, bottom: 0, trailing: 0))
                    Button("Beanie Cat!") { 
                        iconCat = "CatWithHat3"
                    }
                    .offset(x: 100, y: -50) //might change later
                    .tint(lightGreen)
                    .buttonStyle(.bordered)
                }
                VStack {
                    Image("CatWithHat2")
                        .resizable()
                        .frame(width: 250, height: 200)
                        .padding(.init(top: 0, leading: 0, bottom: 0, trailing: 200))
                    Button("Top Hat Cat!") { 
                        iconCat = "CatWithHat2"
                    }
                    .offset(x: -100, y: 30) //might change later
                    .tint(lightGreen)
                    .buttonStyle(.bordered)
                }
                VStack {
                    Image("CatWithHat4")
                        .resizable()
                        .frame(width: 250, height: 200)
                        .padding(.init(top: -250, leading: 200, bottom: 0, trailing: 0))
                    Button("Party Cat!") { 
                        iconCat = "CatWithHat4"
                    }
                    .offset(x: 100, y: -20) //might change later
                    .tint(lightGreen)
                    .buttonStyle(.bordered)
                }
                
            }
            VStack {
                Image(iconCat)
                    .resizable()
                    .frame(width: 250, height: 200)
                    .padding(.init(top: 700, leading: 0, bottom: 0, trailing: 0))
                Text("Your cat!") 
                    .font(.title3)
                    .foregroundStyle(outlineColor)
            }
            
        }   
        
    }
}

#Preview {
    ChooseIconPage()
}


