import SwiftUI

struct WelcomePage: View {
    var body: some View {
        NavigationStack {
            ZStack {
                Color(darkGreen)
                VStack {
                    Image("Logo")
                        .resizable()
                        .frame(maxWidth: 200, maxHeight: 200)
                        .padding(.init(top: 250, leading: 0, bottom: 0, trailing: 0))
                    Text("Cats with Hats")
                        .font(.largeTitle.lowercaseSmallCaps().italic())
                        .padding(.init(top: -360, leading: 0, bottom: 0, trailing: 0))
                        .foregroundStyle(outlineColor)
                    NavigationLink(destination: Games()) {
                        Label("PLAY!", systemImage: "play")
                            .font(.headline)
                            .foregroundStyle(lightGreen)
                            .padding(.init(top: 0, leading: 0, bottom: 0, trailing: 0))
                            .frame(width: 250, height: 50)
                            .background(outlineColor)
                            .cornerRadius(100)
                        
                    }
                    
                }
            }
        }
    }
}

#Preview { 
    WelcomePage()
}
