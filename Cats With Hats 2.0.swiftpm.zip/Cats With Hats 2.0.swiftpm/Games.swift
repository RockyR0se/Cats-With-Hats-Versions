import SwiftUI

struct Games: View {
    var body: some View {
        ZStack {
            Color(darkGreen)
            VStack {
                NavigationLink(destination: CatFigure()) {
                    Label("Mindfulness Board Game", systemImage: "gamecontroller")
                        .font(.headline)
                        .foregroundStyle(lightGreen)
                        .padding(.init(top: 0, leading: 0, bottom: 0, trailing: 0))
                        .frame(width: 260, height: 50)
                        .background(outlineColor)
                        .cornerRadius(100)
                }
                .padding(20)
                NavigationLink(destination: Snake2()) {
                    Label("Creature Collecting Game", systemImage: "gamecontroller")
                        .font(.headline)
                        .foregroundStyle(lightGreen)
                        .padding(.init(top: 0, leading: 0, bottom: 0, trailing: 0))
                        .frame(width: 260, height: 50)
                        .background(outlineColor)
                        .cornerRadius(100)
                }
                .padding(20)
                NavigationLink(destination: TicTacToePage()) {
                    Label("Tic Tac Toe", systemImage: "gamecontroller")
                        .font(.headline)
                        .foregroundStyle(lightGreen)
                        .padding(.init(top: 0, leading: 0, bottom: 0, trailing: 0))
                        .frame(width: 260, height: 50)
                        .background(outlineColor)
                        .cornerRadius(100)
                }
                .padding(20)
                HStack {
                    
                    Label("More Coming Soon!", systemImage: "plus")
                        .font(.headline)
                        .foregroundStyle(lightGreen)
                        .frame(width:260, height: 50)
                        .background(outlineColor)
                        .cornerRadius(100)
                        .padding(.init(top:0, leading: 0, bottom: 0, trailing: 0))
                }
            }
            
        }

        
        
    }
}
#Preview {
    Games()
}
