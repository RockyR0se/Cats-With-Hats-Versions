import SwiftUI

struct Movement: View {
    
    @State public var randomnumber: Int = 1
    @State public var spacesmoved: Int = 0
    @State public var spacesmovedrightfloat: Double = 0
    @State public var spacesmovedleftfloat: Double = 0
    @State public var spacesmovedupfloat: Double = 0
    @State public var spacesmoveddownfloat: Double = 0
    @State public var positionx: Int = 0
    @State public var positiony: Int = 0
    @State public var positionxleaf: Int = 0
    @State public var positionyleaf: Int = 0
    @State public var acorns: Int = 0
    @State public var leafpaddingx: Int = 0
    @State public var leafpaddingy: Int = 0
    @State public var leafpaddingxfloat: Double = 0
    @State public var leafpaddingyfloat: Double = 0
    @State public var disabledx: Int = 0
    @State public var disabledy: Int = 0
    @State public var positionyfloat: Double = 0
    @State public var acornsstring: String = "0"
    @State public var creature: String = "Creature"
    @State public var outfit: String = "Hat"
    @State public var congrats: String = "Can you help me find my hat and bowtie? I need 5 of each!"
    @State public var acorn2: Int = 0
    
    
    var body: some View {
        
        
        
        ZStack {
            Color(darkGreen)
                .ignoresSafeArea()
            Button("Collect") { 
                acorns = acorns + 1
                acorn2 = acorn2 + 1
                positionyfloat = Double(leafpaddingy)
                leafpaddingxfloat = 0
                leafpaddingyfloat = positionyfloat * 2
                //leafpaddingy = 0
                //positiony = leafpaddingy * 2 //fix this
                leafpaddingx = Int.random(in:-3...3)
                leafpaddingy = Int.random(in:0...1)
                leafpaddingxfloat += Double(leafpaddingx) * 235
                leafpaddingyfloat += Double(leafpaddingy) * -235
                //if leafpaddingy == 0 { //try put this in up down instead but mac said it didnt want to load :(
                //positiony = 0
                disabledy = leafpaddingy * 2
                disabledx = leafpaddingx * 2
                acornsstring = String(acorn2)
                if acorns == 5 {
                    creature = "CreatureHat"
                    outfit = "BowTie"
                    acornsstring = "0"
                    congrats = "Just the Bow Tie to go!"
                    acorn2 = 0
                }
                if acorns == 10 {
                    creature = "CreatureHatBowTie"
                    outfit = ""
                    congrats = "Thank you for your help! Would you like to play again?"
                }
                
                
            }
            //disabledx = 100
            //disabledy = 100
            
            //make it so that it randomises every time the acorns is increased and that the collect button is disabled unless the cat has the same positionx and positiony as the acorn. make it so that the randomisation then converts to accurate padding positions aka. number of pips multiplied by 235, (470)
            
            //235 DID NOT WORK PLEASE FIX :((((
            .offset(y:250)
            .buttonStyle(.bordered)
            .tint(lightGreen)
            .disabled(disabledx != positionx || disabledy != positiony)
            
            
            
            Button("Right") { 
                
                withAnimation {
                    randomnumber = 1
                    spacesmovedrightfloat += Double(randomnumber) * 235
                    positionx = positionx + 1
                    //disabledx = leafpaddingx * 2
                    
                }
                
            }
            .buttonStyle(.bordered)
            .tint(lightGreen)
            .offset(y:400)
            .offset(x:100)
            .disabled(positionx == 6)
            Button("Left") { 
                
                withAnimation {
                    randomnumber = 1
                    spacesmovedleftfloat += Double(randomnumber) * 235
                    positionx = positionx - 1
                    //disabledx = leafpaddingx * 2
                    
                }
                
            }
            .buttonStyle(.bordered)
            .tint(lightGreen)
            .offset(y:400)
            .offset(x:-100)
            .disabled(positionx == -6)
            Button("Up") { 
                
                withAnimation {
                    randomnumber = 1
                    spacesmovedupfloat += Double(randomnumber) * 235
                    positiony = positiony + 1
                    //disabledy = leafpaddingy * 2
                    
                    
                }
                
            }
            .buttonStyle(.bordered)
            .tint(lightGreen)
            .offset(y:315)
            .offset(x:0)
            .disabled(positiony == 2)
            
            Button("Down") { 
                
                withAnimation {
                    randomnumber = 1
                    spacesmoveddownfloat += Double(randomnumber) * 235
                    positiony = positiony - 1
                    //disabledy = leafpaddingy * 2
                    
                    
                }
                
            }
            .buttonStyle(.bordered)
            .tint(lightGreen)
            .offset(y:485)
            .offset(x: 0)
            .disabled(positiony == 0)
            
            Image(systemName: "arrow.up.and.down.and.arrow.left.and.right")
                .resizable()
                .frame(maxWidth: 100, maxHeight: 100)
                .aspectRatio(1, contentMode: .fit)
                .foregroundStyle(outlineColor)
                .padding(.init(top: 800, leading: 0, bottom: 0, trailing: 0))
                .foregroundStyle(Color.white)
            
            VStack{
                Image(creature)
                    .resizable()
                    .frame(width: 200, height: 200)
                    .foregroundStyle(.red)
                    .padding(.init(top: spacesmoveddownfloat, leading: spacesmovedrightfloat, bottom: spacesmovedupfloat, trailing: spacesmovedleftfloat))
            }
            
            VStack {
                Image(outfit)
                    .resizable()
                    .frame(width: 200, height: 200)
                    .foregroundStyle(.green)
                    .offset(x:leafpaddingxfloat)
                    .offset(y:leafpaddingyfloat)
                //.padding(.init(top: 0, leading: leafpaddingxfloat, bottom: leafpaddingyfloat, trailing: 0))
                //DID NOT WORK FIX
                
                
                
            }
            VStack {
                Text(acornsstring)
                    .padding(.init(top: 700, leading: 450, bottom: 0, trailing: 0))
                    .foregroundStyle(outlineColor)
                    .font(.largeTitle)
            }
            
            VStack {
                Text(congrats)
                    .font(.largeTitle.lowercaseSmallCaps()
                    .italic())
                    .foregroundStyle(outlineColor)
                    .padding(.init(top: 0, leading: 0, bottom: 800, trailing: 0))
                
                Button("Play Again!") {
                    acorns = 0
                    creature = "Creature"
                    outfit = "Hat"
                    spacesmoveddownfloat = 0
                    spacesmovedupfloat = 0
                    spacesmovedleftfloat = 0
                    spacesmovedrightfloat = 0
                    leafpaddingxfloat = 0
                    leafpaddingyfloat = 0
                    congrats = "Can you help me find my hat and bowtie? I need 5 of each!"
                    acornsstring = "0"
                    disabledx = 0
                    disabledy = 0
                    positionx = 0
                    positiony = 0
                    leafpaddingy = 0
                    leafpaddingx = 0
                    acorn2 = 0
                    acornsstring = "0"
                    
                }
                .buttonStyle(.bordered)
                .tint(lightGreen)
                .disabled(acorns < 10)
                .offset(y:-800)
                
            }
        }
    }
}
