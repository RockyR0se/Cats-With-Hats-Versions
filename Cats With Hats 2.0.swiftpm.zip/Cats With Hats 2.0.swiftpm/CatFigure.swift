import SwiftUI

struct CatFigure: View {
    var body: some View {
        
        ZStack {
            Color(darkGreen)
            Text("Mindfulness BoardGame! <3")
                .font(.largeTitle.lowercaseSmallCaps().italic())
                .padding(.init(top: 0, leading: 0, bottom: 800, trailing: 0))
                .foregroundStyle(outlineColor)
            
            
            
            Image("Board")
                .resizable()
                .frame(width: 750, height: 500)
                .padding(.init(top: 163, leading: 0, bottom: 0, trailing: 0))
            
                
            DiceView()
            
            
            
            Image("Mushroom4")
                .resizable()
                .frame(width: 200, height: 200)
                .padding(.init(top: 700, leading: 0, bottom: 0, trailing: 300))
            Image("Mushroom6")
                .resizable()
                .frame(width: 150, height: 150)
                .padding(.init(top: 400, leading: 500, bottom: 0, trailing: 0))
            Image("Mushroom10")
                .resizable()
                .frame(width: 200, height: 200)
                .padding(.init(top: 500, leading: 0, bottom: 0, trailing: 600))
            Image("Moth")
                .resizable()
                .frame(width: 150, height: 150)
                .padding(.init(top: 800, leading: 300, bottom: 0, trailing: 0))
            Image("Stars")
                .resizable()
                .frame(width: 100, height: 100)
                .padding(.init(top: 500, leading: 200, bottom: 0, trailing: 0))
            

        }
        
    }
}
#Preview {
    CatFigure()
}
