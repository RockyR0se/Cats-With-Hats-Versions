import SwiftUI


let darkGreen = Color(red: 0.33, green: 0.39, blue: 0.32)

let outlineColor = Color(red: 0.18, green: 0.11, blue: 0.11)

let lightGreen = Color(red: 0.61, green: 0.68, blue: 0.44)


