import SwiftUI

struct HowAreYouFeelingPage: View {
    var body: some View {
        ZStack {
            Color(darkGreen)
            VStack {
                Text("How Are You Feeling Today?")
                    .bold()
                    .font(.title)
                    .padding(.init(top: 0, leading: 0, bottom: 750, trailing: 0))
            }
            VStack {
                Image("Happy Cat")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 0, leading: 0, bottom: 400, trailing: 200))
            }
            VStack {
                Text("Happy")
                    .bold()
                    .font(.title2)
                    .padding(.init(top: 0, leading: 0, bottom: 250, trailing: 200))
            }
            VStack {
                Image("Bored Cat")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 0, leading: 200, bottom: 400, trailing: 0))
            }
            VStack {
                Text("Bored")
                    .bold()
                    .font(.title2)
                    .padding(.init(top: 0, leading: 200, bottom: 250, trailing: 0))
            }
            VStack {
                Image("Sad Cat")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .padding(.init(top: 0, leading: 0, bottom: 100, trailing: 0))
            }
            VStack {
                Text("Sad")
                    .bold()
                    .font(.title2)
                    .padding(.init(top: 50, leading: 0, bottom: 0, trailing: 0))
            }
            VStack {
                Text("Monday")
                    .bold()
                    .font(.title2)
                    .padding(.init(top:200, leading: 0, bottom: 0, trailing: 200))
            }
            VStack {
                Text("Tuesday")
                    .bold()
                    .font(.title2)
                    .padding(.init(top:200, leading: 200, bottom: 0, trailing: 0))
            }
            VStack {
                Text("Wednesday")
                    .bold()
                    .font(.title2)
                    .padding(.init(top: 300, leading: 0, bottom: 0, trailing: 200))
            }
            VStack {
                Text("Thursday")
                    .bold()
                    .font(.title2)
                    .padding(.init(top: 300, leading: 200, bottom: 0, trailing: 0))
            }
            VStack {
                Text("Friday")
                    .bold()
                    .font(.title2)
                    .padding(.init(top: 400, leading: 0, bottom: 0, trailing: 200))
            }
            VStack {
                Text("Saturday")
                    .bold()
                    .font(.title2)
                    .padding(.init(top: 400, leading: 200, bottom: 0, trailing: 0))
            }
            VStack {
                Text("Sunday")
                    .bold()
                    .font(.title2)
                    .padding(.init(top: 500, leading: 0, bottom: 0, trailing: 0))
            }
        }
    }
}
#Preview {
    HowAreYouFeelingPage()
}

