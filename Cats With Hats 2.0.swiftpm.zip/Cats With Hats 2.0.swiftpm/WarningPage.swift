import SwiftUI

struct WarningPage: View {
    var body: some View {
        ZStack {
            Color(darkGreen)
            Text("WARNING!")
                .fontWeight(.bold)
                .font(.largeTitle)
                .padding(.init(top: -400, leading: 0, bottom: 0, trailing: 0))
                .padding()
                .multilineTextAlignment(.center)
                .foregroundStyle(outlineColor)
            Text("This app is not guarenteed to work for everybody.")
                .font(.title)
                .padding(.init(top: -250, leading: 20, bottom: 0, trailing: 20))
                .padding()
                .multilineTextAlignment(.center)
                .foregroundStyle(outlineColor)
            Text("If you are experiencing severe issues and problems, please reach out.")
                .font(.title)
                .padding(.init(top: -150, leading: 20, bottom: 0, trailing: 20))
                .padding()
                .multilineTextAlignment(.center)
                .foregroundStyle(outlineColor)
            Text("Kids helpline - 1800 55 1800")
                .padding(.init(top: 40, leading: 0, bottom: 0, trailing: 0))
                .font(.title2)
                .multilineTextAlignment(.center)
                .foregroundStyle(outlineColor)
            Text("Suicide helpline - 13 11 14")
                .padding(.init(top: 90, leading: 0, bottom: 0, trailing: 0))
                .font(.title2)
                .multilineTextAlignment(.center)
                .foregroundStyle(outlineColor)
            Text("Headspace - (03) 9006 6500")
                .padding(.init(top: 140, leading: 0, bottom: 0, trailing: 0))
                .font(.title2)
                .multilineTextAlignment(.center)
                .foregroundStyle(outlineColor)
            Text("LGBTQIA+ helpline - 1800 729 367")
                .padding(.init(top: 190, leading: 0, bottom: 0, trailing: 0))
                .font(.title2)
                .multilineTextAlignment(.center)
                .foregroundStyle(outlineColor)
            Text("OCD and anxiety helpline - 1300 269 438 or 9830 0533")
                .font(.title2)
                .padding(.init(top: 240, leading: 0, bottom: 0, trailing: 0))
                .multilineTextAlignment(.center)
                .foregroundStyle(outlineColor)
            Image("Logo")
                .resizable()
                .frame(width:300, height: 300)
                .padding(.init(top: 600, leading: 0, bottom: 0, trailing: 0))
            Image("Moth")
                .resizable()
                .frame(width: 200, height: 200)
                .padding(.init(top: -430, leading: 250, bottom: 0, trailing: 0))
            Image("Mushroom4")
                .resizable()
                .frame(width: 200, height: 200)
                .padding(.init(top: 740, leading: 0, bottom: 0, trailing: 400))
            
        }
    }
}
#Preview { 
    WarningPage()
}




