import SwiftUI

struct MeetTheDevsPage: View {
    var body: some View {
        ZStack {
            Color(darkGreen)
            
            HStack {
                VStack {
                    HStack {
                        Image("Pippy")
                            .resizable()
                            .frame(width: 150, height: 200)
                            .padding(.init(top: 0, leading: 0, bottom: 0, trailing: 0))
                            .clipShape(Circle())
                        Text("Hi! My name is Evie and I'm one of the developers for Cats with Hats!! My cat's name is Pippi, and she is my silly little fluffball. ")
                            .bold()
                            .multilineTextAlignment(.center)
                            .padding(.init(top: 0, leading: 50, bottom: 0, trailing: 50))
                            .foregroundStyle(outlineColor)                        
                    }
                    
                    HStack {
                        Image("Mimine")
                            .resizable()
                            .frame(width: 150, height: 200)
                            .padding(.init(top: 0, leading: 0, bottom: 0, trailing: 0))
                            .clipShape(Circle())
                        Text("I'm Elodie !! I drew all the assets for Cats with Hats, and was the artist of the team. My cat is Mimine and I love her so much.")
                            .bold()
                            .multilineTextAlignment(.center)
                            .padding(.init(top: 0, leading: 50, bottom: 0, trailing: 50))
                            .foregroundStyle(outlineColor)                            
                    }
                    
                    HStack {
                        Image("Angel")
                            .resizable()
                            .frame(width: 150, height:200)
                            .padding(.init(top: 0, leading: 0, bottom: 0, trailing: 0))
                            .clipShape(Circle())
                        Text("Hi, I’m Kai. I’m one of the developers of Cats with Hats. My cat, Angel, is 14 and I love her very much, she’s the best!")
                            .bold()
                            .padding(.init(top: 0, leading: 50, bottom: 0, trailing: 50))
                            .multilineTextAlignment(.center)
                            .foregroundStyle(outlineColor)                        
                    }
                    Text("Meet the Devs!")
                        .font(.title)
                        .fontWeight(.semibold)
                        .padding(.init(top: -680, leading: 80, bottom: 0, trailing: 0))
                        .foregroundStyle(outlineColor)
                    
                    
                }
            }
            Image("Mushroom4")
                .resizable()
                .frame(width: 150, height: 150)
                .padding(.init(top: 850, leading: 0, bottom: 0, trailing: 500))
            Image("Mushroom8")
                .resizable()
                .frame(width: 150, height: 150)
                .padding(.init(top: 825, leading: 600, bottom: 0, trailing: 0))
            Image("Mushroom13")
                .resizable()
                .frame(width: 150, height: 150)
                .padding(.init(top: 0, leading: 600, bottom: 850, trailing: 0))
            Image("Mushroom2")
                .resizable()
                .frame(width: 150, height: 150)
                .padding(.init(top: 0, leading: 0, bottom: 850, trailing: 500))
        }
        
        
        
    }
}

#Preview { 
    MeetTheDevsPage()
}
